# src/my_model_api/api.py

import pickle
import js
from importlib import resources  # <-- Import this!

# Global cache remains the same
LOADED_MODELS = {}

def load_model(model_filename: str) -> dict:
    """
    Loads a model from a .pkl file bundled *within* this package.
    """
    if model_filename in LOADED_MODELS:
        js.console.log(f"Python: Model '{model_filename}' already in cache.")
        return {"status": "cached", "model": model_filename}

    js.console.log(f"Python: Loading model '{model_filename}' from package resources...")
    
    try:
        # --- THIS IS THE CHANGE ---
        # We must read the file as a package resource, not from the filesystem.
        # 'resources.open_binary' opens a file from within your package.
        # The first argument is your package name: 'my_model_api'
        with resources.open_binary('model_api', model_filename) as f:
            model = pickle.load(f)
        
        LOADED_MODELS[model_filename] = model
        
        js.console.log(f"Python: Model '{model_filename}' loaded and cached.")
        return {"status": "loaded", "model": model_filename}
    
    except FileNotFoundError:
        msg = f"Model file {model_filename} not found in package."
        js.console.error(f"Python: {msg}")
        return {"status": "error", "message": msg}
    except Exception as e:
        js.console.error(f"Python: Error loading model '{model_filename}': {e}")
        return {"status": "error", "message": str(e)}

def predict(model_filename: str, input_data: str) -> dict:
    """
    Performs inference using a pre-loaded model.
    (This function remains the same).
    """
    if model_filename not in LOADED_MODELS:
        return {"status": "error", "message": "Model not loaded."}
    try:
        model = LOADED_MODELS[model_filename]
        prediction = model.predict([input_data])
        return {"status": "success", "prediction": list(prediction)}
    except Exception as e:
        return {"status": "error", "message": str(e)}

print("Python: my_model_api.api module loaded.")